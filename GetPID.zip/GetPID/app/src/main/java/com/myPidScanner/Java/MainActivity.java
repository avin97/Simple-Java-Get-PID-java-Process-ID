package com.myPidScanner.Java;


import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.view.View;
import android.graphics.Typeface;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.net.Uri;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends Activity 
{

int gotPidFromVoid;
    private ArrayList<String> list = new ArrayList<>();

    private LinearLayout linear2;
    private EditText edittext1;
    private LinearLayout linear1;
    private TextView textview1;
	private Button button1;
    
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
            }
            else {
                init();
            }
        }
        else {
            init();
		}
        }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1000) {
            init();
		}
    }
    
    public void init() {
        
        linear2 = (LinearLayout) findViewById(R.id.linear2);
        edittext1 = (EditText) findViewById(R.id.edittext1);
        linear1 = (LinearLayout) findViewById(R.id.linear1);
        textview1 = (TextView) findViewById(R.id.textview1);
		button1 = (Button) findViewById(R.id.button1);
        
        
        edittext1.setTypeface(Typeface.createFromAsset(getAssets(),"moni.ttf"), 0);
        textview1.setTypeface(Typeface.createFromAsset(getAssets(),"moni.ttf"), 0);
		button1.setTypeface(Typeface.createFromAsset(getAssets(),"moni.ttf"), 0);
        
        textview1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View _view) {
                    ((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", String.valueOf((long)(gotPidFromVoid))));
                    SketchwareUtil.showMessage(getApplicationContext(), "Copied Sucessfully!");
                }
            });
            
        button1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View _view) {
                    
                    gotPidFromVoid = getPID(edittext1.getText().toString());
                    if (edittext1.toString().equals("")) {
                        SketchwareUtil.showMessage(getApplicationContext(), "Enter Package Name");
                    } else {
                    if(gotPidFromVoid != 0 || gotPidFromVoid != 0) {
                    SketchwareUtil.showMessage(MainActivity.this,String.valueOf(gotPidFromVoid));
                    
                    textview1.setText("Your PID For This Process Is - ".concat(String.valueOf((long)(gotPidFromVoid))));
                    
                    } else {
                        SketchwareUtil.showMessage(MainActivity.this, "Process Not Detected, Make Sure Its Running");
                        textview1.setText("Your PID For This Process Is - Can't Find");
                    }
                    
                    }
                }
            });
	}
            
    
    public int getPID(String pkg_name) {
        //pkg_name = edittext1.getText().toString();
        int pid = 0;
        int i;
        String file_path;
        
            list.clear();
            i = 0;
            FileUtil.listDir("/proc", list);
            file_path = "";
            for(int _repeat20 = 0; _repeat20 < (int)(list.size()); _repeat20++) {
                file_path = list.get((int)(i));
                if (FileUtil.isDirectory(file_path) && (FileUtil.isExistFile(file_path.concat("/cmdline")) && FileUtil.readFile(file_path.concat("/cmdline")).contains(pkg_name))) {
                    if (Uri.parse(file_path).getLastPathSegment().equals("self") || Uri.parse(file_path).getLastPathSegment().equals("thread-self")) {

                    }
                    else {
                        pid = (int) Double.parseDouble(Uri.parse(file_path).getLastPathSegment());
                    }
                }
                i++;
            }
            if (!(pid == 0)) {
                return pid;
            }
            
        return 0;
    }
       
    
}
